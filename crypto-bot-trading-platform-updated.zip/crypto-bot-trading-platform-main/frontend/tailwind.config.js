/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0A0E14',
          900: '#10161F',
          800: '#161D28',
          700: '#232B36',
          600: '#2E3844',
        },
        mist: {
          400: '#5B6577',
          300: '#8A94A6',
          100: '#DCE1E8',
          50: '#E8ECEF',
        },
        gold: {
          500: '#E8A33D',
          400: '#F0B968',
        },
        rise: '#3DDC97',
        fall: '#E85D5D',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
      },
    },
  },
  plugins: [],
}
