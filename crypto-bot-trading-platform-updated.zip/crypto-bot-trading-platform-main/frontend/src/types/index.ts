export interface User {
  id: string;
  email: string;
  username: string;
  full_name?: string;
  is_active: boolean;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
}

export type TradingMode =
  | 'AUTO_GRID'
  | 'AUTO_GRID_FUTURES'
  | 'FUTURES_GRID'
  | 'DCA_FUTURES'
  | 'MARTINGALE'
  | 'MARTINGALE_FUTURES'
  | 'SNOWBALL_GRID'
  | 'SNOWBALL_FUTURES';

export type BotStatus = 'active' | 'paused' | 'stopped' | 'error';

export interface TradingBot {
  id: string;
  user_id: string;
  exchange_api_key_id: string;
  name: string;
  description?: string;
  symbol: string;
  trading_mode: TradingMode;
  status: BotStatus;
  is_paper_trading: boolean;
  initial_capital: string | number;
  position_size?: string | number;
  leverage?: string | number;
  timeframe: string;
  use_indicators: boolean;
  min_signal_strength: string | number;
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  win_rate: string | number;
  settings?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export type OrderStatus = 'pending' | 'open' | 'filled' | 'canceled' | 'rejected' | string;
export type OrderSide = 'buy' | 'sell' | string;
export type OrderType = 'limit' | 'market' | string;

export interface Order {
  id: string;
  bot_id?: string;
  user_id: string;
  exchange_order_id?: string;
  symbol: string;
  order_type: OrderType;
  order_side: OrderSide;
  status: OrderStatus;
  price?: string | number;
  amount: string | number;
  filled?: string | number;
  remaining?: string | number;
  total_cost?: string | number;
  fee?: string | number;
  created_at: string;
  updated_at: string;
  filled_at?: string;
}

export interface ExchangeApiKey {
  id: string;
  user_id: string;
  exchange_name: string;
  api_key: string;
  is_active: boolean;
  last_tested_at?: string;
  test_status?: string;
  created_at: string;
  updated_at: string;
}

export type TradingSignal = 'BUY' | 'SELL' | 'HOLD';

export interface SignalIndicators {
  supertrend?: number;
  ma20?: number;
  ma50?: number;
  stochRSI?: number;
  kdj?: number;
  obv?: number;
  macd?: number;
}

export interface SignalResult {
  symbol: string;
  signal: TradingSignal;
  strength?: number;
  confidence?: number;
  reasoning?: string[];
  indicators?: SignalIndicators;
  currentPrice?: number;
  timestamp?: string;
  [key: string]: any;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
