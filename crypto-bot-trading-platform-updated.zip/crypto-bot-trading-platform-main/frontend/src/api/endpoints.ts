import client from './client';
import type {
  ApiResponse,
  ExchangeApiKey,
  Order,
  SignalResult,
  TradingBot,
  User,
} from '../types';

// ---- Auth ----
export const authApi = {
  register: (payload: { email: string; username: string; password: string; fullName?: string }) =>
    client.post<ApiResponse<{ user: User; token: string }>>('/api/auth/register', payload),
  login: (payload: { email: string; password: string }) =>
    client.post<ApiResponse<{ user: User; token: string }>>('/api/auth/login', payload),
  me: () => client.get<ApiResponse<User>>('/api/auth/me'),
};

// ---- Trading bots ----
export const botsApi = {
  list: () => client.get<ApiResponse<TradingBot[]>>('/api/bots'),
  get: (id: string) => client.get<ApiResponse<TradingBot>>(`/api/bots/${id}`),
  create: (payload: Record<string, any>) => client.post<ApiResponse<TradingBot>>('/api/bots', payload),
  update: (id: string, payload: Record<string, any>) =>
    client.put<ApiResponse<TradingBot>>(`/api/bots/${id}`, payload),
  setStatus: (id: string, status: string) =>
    client.patch<ApiResponse<null>>(`/api/bots/${id}/status`, { status }),
  remove: (id: string) => client.delete<ApiResponse<null>>(`/api/bots/${id}`),
};

// ---- Orders ----
export const ordersApi = {
  list: (limit = 50) => client.get<ApiResponse<Order[]>>(`/api/orders?limit=${limit}`),
  get: (id: string) => client.get<ApiResponse<Order>>(`/api/orders/${id}`),
  byBot: (botId: string) => client.get<ApiResponse<Order[]>>(`/api/orders/bot/${botId}`),
};

// ---- Exchange API keys ----
export const exchangeKeysApi = {
  list: () => client.get<ApiResponse<ExchangeApiKey[]>>('/api/exchange-keys'),
  create: (payload: { exchangeName: string; apiKey: string; apiSecret: string; passphrase?: string }) =>
    client.post<ApiResponse<ExchangeApiKey>>('/api/exchange-keys', payload),
  remove: (id: string) => client.delete<ApiResponse<null>>(`/api/exchange-keys/${id}`),
};

// ---- Exchange info ----
export const exchangeApi = {
  supported: () => client.get<ApiResponse<string[]>>('/api/exchange/supported'),
  balance: (exchange: string) => client.get<ApiResponse<any>>(`/api/exchange/balance/${exchange}`),
};

// ---- Market data ----
export const marketApi = {
  data: (exchange: string, symbol: string) =>
    client.get<ApiResponse<any>>(`/api/market/data/${exchange}/${encodeURIComponent(symbol)}`),
  pairs: (exchange: string) => client.get<ApiResponse<string[]>>(`/api/market/pairs/${exchange}`),
};

// ---- Signals ----
export const signalsApi = {
  generate: (exchange: string, symbol: string, timeframe?: string) =>
    client.post<ApiResponse<SignalResult>>(
      `/api/signals/generate/${exchange}/${encodeURIComponent(symbol)}`,
      { timeframe }
    ),
  scan: (exchange: string, symbols: string[]) =>
    client.post<ApiResponse<SignalResult[]>>(`/api/signals/scan/${exchange}`, { symbols }),
};
