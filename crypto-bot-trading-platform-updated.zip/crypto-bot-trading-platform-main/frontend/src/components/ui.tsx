import React from 'react';

export function StatCard({
  label,
  value,
  hint,
  tone = 'default',
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  tone?: 'default' | 'rise' | 'fall';
}) {
  const toneClass = tone === 'rise' ? 'text-rise' : tone === 'fall' ? 'text-fall' : 'text-mist-50';
  return (
    <div className="border border-ink-700 bg-ink-900 rounded-sm px-5 py-4">
      <div className="text-xs text-mist-300 tracking-wide">{label}</div>
      <div className={`num text-2xl mt-1 ${toneClass}`}>{value}</div>
      {hint && <div className="text-xs text-mist-400 mt-1">{hint}</div>}
    </div>
  );
}

export function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    active: 'bg-rise/10 text-rise border-rise/30',
    open: 'bg-rise/10 text-rise border-rise/30',
    filled: 'bg-rise/10 text-rise border-rise/30',
    paused: 'bg-gold-500/10 text-gold-400 border-gold-500/30',
    pending: 'bg-gold-500/10 text-gold-400 border-gold-500/30',
    stopped: 'bg-mist-400/10 text-mist-300 border-mist-400/30',
    canceled: 'bg-mist-400/10 text-mist-300 border-mist-400/30',
    error: 'bg-fall/10 text-fall border-fall/30',
    rejected: 'bg-fall/10 text-fall border-fall/30',
  };
  const cls = map[status] || 'bg-mist-400/10 text-mist-300 border-mist-400/30';
  return (
    <span className={`inline-block px-2 py-0.5 text-xs rounded-sm border ${cls}`}>
      {status}
    </span>
  );
}

export function SideBySide({ side }: { side: string }) {
  const isBuy = side?.toLowerCase() === 'buy';
  return (
    <span className={`text-xs font-medium ${isBuy ? 'text-rise' : 'text-fall'}`}>
      {isBuy ? 'BUY' : 'SELL'}
    </span>
  );
}

export function Button({
  children,
  variant = 'primary',
  className = '',
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'ghost' | 'danger' }) {
  const base = 'px-4 py-2 rounded-sm text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed';
  const variants: Record<string, string> = {
    primary: 'bg-gold-500 text-ink-950 hover:bg-gold-400',
    ghost: 'border border-ink-600 text-mist-100 hover:border-mist-300',
    danger: 'border border-fall/40 text-fall hover:bg-fall/10',
  };
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="block text-xs text-mist-300 mb-1">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  'w-full bg-ink-950 border border-ink-600 rounded-sm px-3 py-2 text-sm text-mist-50 placeholder:text-mist-400 focus:border-gold-500 outline-none';

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="border border-dashed border-ink-600 rounded-sm py-12 text-center">
      <div className="text-mist-100">{title}</div>
      {hint && <div className="text-sm text-mist-400 mt-1">{hint}</div>}
    </div>
  );
}
