import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { logout } from '../store/authSlice';

const navItems = [
  { to: '/', label: 'Overview', end: true },
  { to: '/bots', label: 'Bots' },
  { to: '/orders', label: 'Orders' },
  { to: '/signals', label: 'Signals' },
  { to: '/exchange-keys', label: 'Exchange keys' },
];

export default function Layout() {
  const user = useAppSelector((s) => s.auth.user);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  function handleLogout() {
    dispatch(logout());
    navigate('/login');
  }

  return (
    <div className="min-h-screen bg-ink-950 text-mist-50 font-body flex">
      <aside className="w-56 shrink-0 border-r border-ink-700 flex flex-col">
        <div className="px-5 py-5 border-b border-ink-700">
          <div className="font-display font-semibold text-lg tracking-tight">Ledgerline</div>
          <div className="text-xs text-mist-400 mt-0.5">Automated trading desk</div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block px-3 py-2 rounded-sm text-sm transition-colors ${
                  isActive
                    ? 'bg-ink-800 text-gold-400'
                    : 'text-mist-300 hover:text-mist-50 hover:bg-ink-900'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="px-5 py-4 border-t border-ink-700">
          <div className="text-sm text-mist-100 truncate">{user?.username}</div>
          <div className="text-xs text-mist-400 truncate">{user?.email}</div>
          <button
            onClick={handleLogout}
            className="mt-3 text-xs text-mist-400 hover:text-fall transition-colors"
          >
            Sign out
          </button>
        </div>
      </aside>
      <main className="flex-1 min-w-0 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-8 py-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
