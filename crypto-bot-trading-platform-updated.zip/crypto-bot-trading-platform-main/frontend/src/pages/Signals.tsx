import React, { useState } from 'react';
import { signalsApi } from '../api/endpoints';
import type { SignalResult } from '../types';
import { Button, Field, inputClass } from '../components/ui';

const SIGNAL_TONE: Record<string, string> = {
  BUY: 'text-rise border-rise/30 bg-rise/10',
  SELL: 'text-fall border-fall/30 bg-fall/10',
  HOLD: 'text-gold-400 border-gold-500/30 bg-gold-500/10',
};

export default function Signals() {
  const [exchange, setExchange] = useState('binance');
  const [symbol, setSymbol] = useState('BTC/USDT');
  const [timeframe, setTimeframe] = useState('1h');
  const [result, setResult] = useState<SignalResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await signalsApi.generate(exchange, symbol, timeframe);
      setResult(res.data.data || null);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to generate signal');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-semibold text-2xl">Signals</h1>
        <p className="text-mist-400 text-sm mt-1">
          Generate an on-demand technical signal from the combined indicator engine.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="border border-ink-700 bg-ink-900 rounded-sm p-5">
        <div className="grid grid-cols-3 gap-4">
          <Field label="Exchange">
            <input className={inputClass} value={exchange} onChange={(e) => setExchange(e.target.value)} />
          </Field>
          <Field label="Symbol">
            <input className={inputClass} value={symbol} onChange={(e) => setSymbol(e.target.value)} />
          </Field>
          <Field label="Timeframe">
            <select className={inputClass} value={timeframe} onChange={(e) => setTimeframe(e.target.value)}>
              {['5m', '15m', '1h', '4h', '1d'].map((tf) => (
                <option key={tf} value={tf}>
                  {tf}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Button type="submit" className="mt-4" disabled={loading}>
          {loading ? 'Analyzing…' : 'Generate signal'}
        </Button>
      </form>

      {error && <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">{error}</div>}

      {result && (
        <div className="border border-ink-700 rounded-sm p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-mist-400">{result.symbol}</div>
              <div className="font-display text-xl">{timeframe} signal</div>
            </div>
            <span className={`px-3 py-1 rounded-sm border text-sm font-medium ${SIGNAL_TONE[result.signal] || ''}`}>
              {result.signal}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {result.confidence !== undefined && (
              <Metric label="Confidence" value={`${result.confidence}%`} />
            )}
            {result.strength !== undefined && <Metric label="Strength" value={`${result.strength}%`} />}
            {result.currentPrice !== undefined && (
              <Metric label="Price" value={String(result.currentPrice)} mono />
            )}
            {result.indicators &&
              Object.entries(result.indicators).map(([key, value]) => (
                <Metric key={key} label={key} value={String(value)} mono />
              ))}
          </div>

          {result.reasoning && result.reasoning.length > 0 && (
            <div>
              <div className="text-xs text-mist-400 mb-2">Reasoning</div>
              <ul className="text-sm text-mist-100 space-y-1 list-disc list-inside">
                {result.reasoning.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Metric({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="border border-ink-700 rounded-sm px-3 py-2">
      <div className="text-xs text-mist-400 capitalize">{label}</div>
      <div className={`text-sm text-mist-50 mt-0.5 ${mono ? 'num' : ''}`}>{value}</div>
    </div>
  );
}
