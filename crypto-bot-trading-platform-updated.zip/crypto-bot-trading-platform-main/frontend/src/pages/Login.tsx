import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { login, clearError } from '../store/authSlice';
import { Button, Field, inputClass } from '../components/ui';

export default function Login() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { status, error } = useAppSelector((s) => s.auth);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    dispatch(clearError());
    const result = await dispatch(login({ email, password }));
    if (login.fulfilled.match(result)) {
      navigate('/');
    }
  }

  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="font-display font-semibold text-2xl text-mist-50">Ledgerline</div>
          <div className="text-sm text-mist-400 mt-1">Sign in to your trading desk</div>
        </div>
        <form onSubmit={handleSubmit} className="border border-ink-700 bg-ink-900 rounded-sm p-6 space-y-4">
          {error && (
            <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">
              {error}
            </div>
          )}
          <Field label="Email">
            <input
              type="email"
              required
              className={inputClass}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </Field>
          <Field label="Password">
            <input
              type="password"
              required
              className={inputClass}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </Field>
          <Button type="submit" className="w-full" disabled={status === 'loading'}>
            {status === 'loading' ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>
        <p className="text-sm text-mist-400 text-center mt-4">
          No account yet?{' '}
          <Link to="/register" className="text-gold-400 hover:text-gold-500">
            Create one
          </Link>
        </p>
      </div>
    </div>
  );
}
