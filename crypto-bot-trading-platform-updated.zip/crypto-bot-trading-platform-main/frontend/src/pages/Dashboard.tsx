import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { botsApi, ordersApi } from '../api/endpoints';
import type { Order, TradingBot } from '../types';
import { StatCard, StatusPill, SideBySide, EmptyState } from '../components/ui';

export default function Dashboard() {
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [botsRes, ordersRes] = await Promise.all([botsApi.list(), ordersApi.list(8)]);
        setBots(botsRes.data.data || []);
        setOrders(ordersRes.data.data || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const activeBots = bots.filter((b) => b.status === 'active');
  const totalTrades = bots.reduce((sum, b) => sum + (b.total_trades || 0), 0);
  const avgWinRate =
    bots.length > 0
      ? (bots.reduce((sum, b) => sum + Number(b.win_rate || 0), 0) / bots.length).toFixed(1)
      : '0.0';

  if (loading) {
    return <div className="text-mist-400 text-sm">Loading your desk…</div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display font-semibold text-2xl">Overview</h1>
        <p className="text-mist-400 text-sm mt-1">Where your bots and orders stand right now.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Active bots" value={activeBots.length} hint={`of ${bots.length} total`} />
        <StatCard label="Total trades" value={totalTrades} />
        <StatCard label="Avg. win rate" value={`${avgWinRate}%`} tone={Number(avgWinRate) >= 50 ? 'rise' : 'fall'} />
        <StatCard label="Recent orders" value={orders.length} />
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-medium text-lg">Bots</h2>
          <Link to="/bots" className="text-sm text-gold-400 hover:text-gold-500">
            Manage bots →
          </Link>
        </div>
        {bots.length === 0 ? (
          <EmptyState title="No bots yet" hint="Create one from the Bots page to start trading." />
        ) : (
          <div className="border border-ink-700 rounded-sm divide-y divide-ink-700">
            {bots.slice(0, 5).map((bot) => (
              <div key={bot.id} className="flex items-center justify-between px-4 py-3">
                <div>
                  <div className="text-sm text-mist-50">{bot.name}</div>
                  <div className="text-xs text-mist-400">
                    {bot.symbol} · {bot.trading_mode}
                  </div>
                </div>
                <StatusPill status={bot.status} />
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-medium text-lg">Recent orders</h2>
          <Link to="/orders" className="text-sm text-gold-400 hover:text-gold-500">
            View all →
          </Link>
        </div>
        {orders.length === 0 ? (
          <EmptyState title="No orders yet" hint="Orders placed by your bots will show up here." />
        ) : (
          <div className="border border-ink-700 rounded-sm divide-y divide-ink-700">
            {orders.map((order) => (
              <div key={order.id} className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <SideBySide side={order.order_side} />
                  <div className="text-sm text-mist-50">{order.symbol}</div>
                </div>
                <div className="num text-sm text-mist-300">{order.amount}</div>
                <StatusPill status={order.status} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
