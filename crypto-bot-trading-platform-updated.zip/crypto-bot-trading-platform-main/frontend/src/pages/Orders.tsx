import React, { useEffect, useState } from 'react';
import { ordersApi } from '../api/endpoints';
import type { Order } from '../types';
import { EmptyState, SideBySide, StatusPill } from '../components/ui';

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    ordersApi
      .list(100)
      .then((res) => setOrders(res.data.data || []))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="text-mist-400 text-sm">Loading orders…</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-semibold text-2xl">Orders</h1>
        <p className="text-mist-400 text-sm mt-1">Every order your bots have placed, most recent first.</p>
      </div>

      {orders.length === 0 ? (
        <EmptyState title="No orders yet" hint="Orders placed by your bots will appear here." />
      ) : (
        <div className="border border-ink-700 rounded-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-mist-400 border-b border-ink-700 bg-ink-900">
                <th className="px-4 py-2 font-normal">Symbol</th>
                <th className="px-4 py-2 font-normal">Side</th>
                <th className="px-4 py-2 font-normal">Type</th>
                <th className="px-4 py-2 font-normal text-right">Price</th>
                <th className="px-4 py-2 font-normal text-right">Amount</th>
                <th className="px-4 py-2 font-normal">Status</th>
                <th className="px-4 py-2 font-normal">Placed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-700">
              {orders.map((order) => (
                <tr key={order.id}>
                  <td className="px-4 py-3 text-mist-50">{order.symbol}</td>
                  <td className="px-4 py-3">
                    <SideBySide side={order.order_side} />
                  </td>
                  <td className="px-4 py-3 text-mist-300">{order.order_type}</td>
                  <td className="px-4 py-3 text-right num text-mist-100">
                    {order.price ?? '—'}
                  </td>
                  <td className="px-4 py-3 text-right num text-mist-100">{order.amount}</td>
                  <td className="px-4 py-3">
                    <StatusPill status={order.status} />
                  </td>
                  <td className="px-4 py-3 text-mist-400 text-xs">
                    {new Date(order.created_at).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
