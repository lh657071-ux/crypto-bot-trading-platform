import React, { useEffect, useState } from 'react';
import { exchangeApi, exchangeKeysApi } from '../api/endpoints';
import type { ExchangeApiKey } from '../types';
import { Button, EmptyState, Field, inputClass } from '../components/ui';

export default function ExchangeKeys() {
  const [keys, setKeys] = useState<ExchangeApiKey[]>([]);
  const [supported, setSupported] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    const res = await exchangeKeysApi.list();
    setKeys(res.data.data || []);
  }

  useEffect(() => {
    Promise.all([
      exchangeKeysApi.list().then((r) => setKeys(r.data.data || [])),
      exchangeApi
        .supported()
        .then((r) => setSupported(r.data.data || []))
        .catch(() => setSupported(['binance', 'bybit', 'okx', 'kucoin'])),
    ]).finally(() => setLoading(false));
  }, []);

  async function handleDelete(key: ExchangeApiKey) {
    if (!confirm(`Remove the ${key.exchange_name} API key? Bots using it will stop working.`)) return;
    try {
      await exchangeKeysApi.remove(key.id);
      await refresh();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to remove key');
    }
  }

  if (loading) return <div className="text-mist-400 text-sm">Loading exchange keys…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-semibold text-2xl">Exchange keys</h1>
          <p className="text-mist-400 text-sm mt-1">
            API keys are stored encrypted server-side and are required before a bot can trade.
          </p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>{showForm ? 'Close' : 'Add key'}</Button>
      </div>

      {error && <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">{error}</div>}

      {showForm && (
        <AddKeyForm
          supported={supported}
          onCreated={() => {
            setShowForm(false);
            refresh();
          }}
        />
      )}

      {keys.length === 0 ? (
        <EmptyState title="No exchange keys connected" hint="Add one to let your bots trade on your behalf." />
      ) : (
        <div className="border border-ink-700 rounded-sm divide-y divide-ink-700">
          {keys.map((key) => (
            <div key={key.id} className="px-4 py-3 flex items-center justify-between">
              <div>
                <div className="text-sm text-mist-50 capitalize">{key.exchange_name}</div>
                <div className="text-xs text-mist-400 num">
                  {key.api_key.slice(0, 4)}••••••••{key.api_key.slice(-4)}
                </div>
              </div>
              <Button variant="danger" onClick={() => handleDelete(key)}>
                Remove
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AddKeyForm({ supported, onCreated }: { supported: string[]; onCreated: () => void }) {
  const [form, setForm] = useState({
    exchangeName: supported[0] || 'binance',
    apiKey: '',
    apiSecret: '',
    passphrase: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update(field: string) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      await exchangeKeysApi.create(form);
      onCreated();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to save key');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="border border-ink-700 bg-ink-900 rounded-sm p-5 space-y-4">
      {error && <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">{error}</div>}
      <Field label="Exchange">
        <select className={inputClass} value={form.exchangeName} onChange={update('exchangeName')}>
          {(supported.length ? supported : ['binance', 'bybit', 'okx', 'kucoin']).map((ex) => (
            <option key={ex} value={ex}>
              {ex}
            </option>
          ))}
        </select>
      </Field>
      <Field label="API key">
        <input required className={inputClass} value={form.apiKey} onChange={update('apiKey')} />
      </Field>
      <Field label="API secret">
        <input required type="password" className={inputClass} value={form.apiSecret} onChange={update('apiSecret')} />
      </Field>
      <Field label="Passphrase (some exchanges only)">
        <input className={inputClass} value={form.passphrase} onChange={update('passphrase')} />
      </Field>
      <Button type="submit" disabled={submitting}>
        {submitting ? 'Saving…' : 'Save key'}
      </Button>
    </form>
  );
}
