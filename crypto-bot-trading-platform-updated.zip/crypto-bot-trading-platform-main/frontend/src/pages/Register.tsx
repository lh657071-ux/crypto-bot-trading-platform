import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { register, clearError } from '../store/authSlice';
import { Button, Field, inputClass } from '../components/ui';

export default function Register() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { status, error } = useAppSelector((s) => s.auth);
  const [form, setForm] = useState({ email: '', username: '', password: '', fullName: '' });

  function update(field: string) {
    return (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    dispatch(clearError());
    const result = await dispatch(register(form));
    if (register.fulfilled.match(result)) {
      navigate('/');
    }
  }

  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="font-display font-semibold text-2xl text-mist-50">Ledgerline</div>
          <div className="text-sm text-mist-400 mt-1">Create your trading desk account</div>
        </div>
        <form onSubmit={handleSubmit} className="border border-ink-700 bg-ink-900 rounded-sm p-6 space-y-4">
          {error && (
            <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">
              {error}
            </div>
          )}
          <Field label="Full name (optional)">
            <input className={inputClass} value={form.fullName} onChange={update('fullName')} placeholder="Ada Lovelace" />
          </Field>
          <Field label="Username">
            <input required className={inputClass} value={form.username} onChange={update('username')} placeholder="ada" />
          </Field>
          <Field label="Email">
            <input
              type="email"
              required
              className={inputClass}
              value={form.email}
              onChange={update('email')}
              placeholder="you@example.com"
            />
          </Field>
          <Field label="Password">
            <input
              type="password"
              required
              minLength={8}
              className={inputClass}
              value={form.password}
              onChange={update('password')}
              placeholder="At least 8 characters"
            />
          </Field>
          <Button type="submit" className="w-full" disabled={status === 'loading'}>
            {status === 'loading' ? 'Creating account…' : 'Create account'}
          </Button>
        </form>
        <p className="text-sm text-mist-400 text-center mt-4">
          Already have an account?{' '}
          <Link to="/login" className="text-gold-400 hover:text-gold-500">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
