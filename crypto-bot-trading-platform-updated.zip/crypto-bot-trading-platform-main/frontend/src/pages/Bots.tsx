import React, { useEffect, useState } from 'react';
import { botsApi, exchangeKeysApi } from '../api/endpoints';
import type { ExchangeApiKey, TradingBot, TradingMode } from '../types';
import { Button, EmptyState, Field, StatusPill, inputClass } from '../components/ui';

const TRADING_MODES: TradingMode[] = [
  'AUTO_GRID',
  'AUTO_GRID_FUTURES',
  'FUTURES_GRID',
  'DCA_FUTURES',
  'MARTINGALE',
  'MARTINGALE_FUTURES',
  'SNOWBALL_GRID',
  'SNOWBALL_FUTURES',
];

export default function Bots() {
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [keys, setKeys] = useState<ExchangeApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    const [botsRes, keysRes] = await Promise.all([botsApi.list(), exchangeKeysApi.list()]);
    setBots(botsRes.data.data || []);
    setKeys(keysRes.data.data || []);
  }

  useEffect(() => {
    refresh().finally(() => setLoading(false));
  }, []);

  async function handleStatus(bot: TradingBot, status: string) {
    setBusyId(bot.id);
    try {
      await botsApi.setStatus(bot.id, status);
      await refresh();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to update bot');
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(bot: TradingBot) {
    if (!confirm(`Delete bot "${bot.name}"? This cannot be undone.`)) return;
    setBusyId(bot.id);
    try {
      await botsApi.remove(bot.id);
      await refresh();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to delete bot');
    } finally {
      setBusyId(null);
    }
  }

  if (loading) return <div className="text-mist-400 text-sm">Loading bots…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-semibold text-2xl">Bots</h1>
          <p className="text-mist-400 text-sm mt-1">Configure and control your automated strategies.</p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>{showForm ? 'Close' : 'New bot'}</Button>
      </div>

      {error && (
        <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">{error}</div>
      )}

      {showForm && (
        <CreateBotForm
          keys={keys}
          onCreated={() => {
            setShowForm(false);
            refresh();
          }}
        />
      )}

      {bots.length === 0 ? (
        <EmptyState
          title="No bots yet"
          hint={keys.length === 0 ? 'Add an exchange API key first, then create a bot.' : 'Create your first bot above.'}
        />
      ) : (
        <div className="border border-ink-700 rounded-sm divide-y divide-ink-700">
          {bots.map((bot) => (
            <div key={bot.id} className="px-4 py-4 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-mist-50 font-medium">{bot.name}</span>
                  <StatusPill status={bot.status} />
                  {bot.is_paper_trading && (
                    <span className="text-xs text-gold-400 border border-gold-500/30 bg-gold-500/10 rounded-sm px-1.5 py-0.5">
                      paper
                    </span>
                  )}
                </div>
                <div className="text-xs text-mist-400 mt-1">
                  {bot.symbol} · {bot.trading_mode} · {bot.timeframe} ·{' '}
                  <span className="num">{bot.win_rate}%</span> win rate ·{' '}
                  <span className="num">{bot.total_trades}</span> trades
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {bot.status !== 'active' && (
                  <Button variant="ghost" disabled={busyId === bot.id} onClick={() => handleStatus(bot, 'active')}>
                    Start
                  </Button>
                )}
                {bot.status === 'active' && (
                  <Button variant="ghost" disabled={busyId === bot.id} onClick={() => handleStatus(bot, 'paused')}>
                    Pause
                  </Button>
                )}
                {bot.status !== 'stopped' && (
                  <Button variant="ghost" disabled={busyId === bot.id} onClick={() => handleStatus(bot, 'stopped')}>
                    Stop
                  </Button>
                )}
                <Button variant="danger" disabled={busyId === bot.id} onClick={() => handleDelete(bot)}>
                  Delete
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CreateBotForm({ keys, onCreated }: { keys: ExchangeApiKey[]; onCreated: () => void }) {
  const [form, setForm] = useState({
    exchangeApiKeyId: keys[0]?.id || '',
    name: '',
    symbol: 'BTC/USDT',
    tradingMode: 'AUTO_GRID' as TradingMode,
    initialCapital: '1000',
    timeframe: '1h',
    isPaperTrading: true,
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update(field: string) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const value =
        e.target instanceof HTMLInputElement && e.target.type === 'checkbox'
          ? e.target.checked
          : e.target.value;
      setForm((f) => ({ ...f, [field]: value }));
    };
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      await botsApi.create({
        ...form,
        initialCapital: Number(form.initialCapital),
      });
      onCreated();
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to create bot');
    } finally {
      setSubmitting(false);
    }
  }

  if (keys.length === 0) {
    return (
      <EmptyState
        title="No exchange API keys connected"
        hint="Add one from the Exchange keys page before creating a bot."
      />
    );
  }

  return (
    <form onSubmit={handleSubmit} className="border border-ink-700 bg-ink-900 rounded-sm p-5 space-y-4">
      {error && <div className="text-sm text-fall bg-fall/10 border border-fall/30 rounded-sm px-3 py-2">{error}</div>}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Bot name">
          <input required className={inputClass} value={form.name} onChange={update('name')} placeholder="BTC grid bot" />
        </Field>
        <Field label="Symbol">
          <input required className={inputClass} value={form.symbol} onChange={update('symbol')} />
        </Field>
        <Field label="Exchange API key">
          <select className={inputClass} value={form.exchangeApiKeyId} onChange={update('exchangeApiKeyId')}>
            {keys.map((k) => (
              <option key={k.id} value={k.id}>
                {k.exchange_name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Trading mode">
          <select className={inputClass} value={form.tradingMode} onChange={update('tradingMode')}>
            {TRADING_MODES.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Initial capital (USDT)">
          <input
            type="number"
            min="0"
            step="any"
            required
            className={inputClass}
            value={form.initialCapital}
            onChange={update('initialCapital')}
          />
        </Field>
        <Field label="Timeframe">
          <select className={inputClass} value={form.timeframe} onChange={update('timeframe')}>
            {['5m', '15m', '1h', '4h', '1d'].map((tf) => (
              <option key={tf} value={tf}>
                {tf}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <label className="flex items-center gap-2 text-sm text-mist-300">
        <input type="checkbox" checked={form.isPaperTrading} onChange={update('isPaperTrading')} />
        Paper trading (simulate without placing real orders)
      </label>
      <Button type="submit" disabled={submitting}>
        {submitting ? 'Creating…' : 'Create bot'}
      </Button>
    </form>
  );
}
