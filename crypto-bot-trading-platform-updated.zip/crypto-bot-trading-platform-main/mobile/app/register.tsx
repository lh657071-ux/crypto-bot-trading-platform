import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { useAppDispatch, useAppSelector } from '../src/store/hooks';
import { register, clearError } from '../src/store/authSlice';
import { PrimaryButton } from '../src/components/ui';
import { colors } from '../src/theme';

export default function RegisterScreen() {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { status, error } = useAppSelector((s) => s.auth);
  const [form, setForm] = useState({ email: '', username: '', password: '', fullName: '' });

  function set(field: keyof typeof form) {
    return (value: string) => setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit() {
    dispatch(clearError());
    const result = await dispatch(register(form));
    if (register.fulfilled.match(result)) {
      router.replace('/(tabs)');
    }
  }

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}>
        <View style={styles.header}>
          <Text style={styles.brand}>Ledgerline</Text>
          <Text style={styles.sub}>Create your trading desk account</Text>
        </View>

        <View style={styles.card}>
          {error ? <Text style={styles.error}>{error}</Text> : null}

          <Text style={styles.label}>Full name (optional)</Text>
          <TextInput style={styles.input} value={form.fullName} onChangeText={set('fullName')} placeholderTextColor={colors.mist400} />

          <Text style={styles.label}>Username</Text>
          <TextInput style={styles.input} value={form.username} onChangeText={set('username')} autoCapitalize="none" placeholderTextColor={colors.mist400} />

          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            value={form.email}
            onChangeText={set('email')}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholderTextColor={colors.mist400}
          />

          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            value={form.password}
            onChangeText={set('password')}
            secureTextEntry
            placeholder="At least 8 characters"
            placeholderTextColor={colors.mist400}
          />

          <View style={{ marginTop: 8 }}>
            <PrimaryButton
              label={status === 'loading' ? 'Creating account…' : 'Create account'}
              onPress={handleSubmit}
              loading={status === 'loading'}
            />
          </View>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Already have an account? </Text>
          <Link href="/login" style={styles.link}>
            Sign in
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink950, padding: 24 },
  header: { alignItems: 'center', marginBottom: 24 },
  brand: { color: colors.mist50, fontSize: 26, fontWeight: '700' },
  sub: { color: colors.mist400, fontSize: 13, marginTop: 4 },
  card: { backgroundColor: colors.ink900, borderColor: colors.ink700, borderWidth: 1, borderRadius: 4, padding: 20 },
  label: { color: colors.mist300, fontSize: 12, marginBottom: 6, marginTop: 12 },
  input: {
    backgroundColor: colors.ink950,
    borderColor: colors.ink600,
    borderWidth: 1,
    borderRadius: 4,
    color: colors.mist50,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  error: {
    color: colors.fall,
    backgroundColor: colors.fall + '1A',
    borderColor: colors.fall + '4D',
    borderWidth: 1,
    borderRadius: 4,
    padding: 10,
    fontSize: 13,
  },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 20 },
  footerText: { color: colors.mist400, fontSize: 13 },
  link: { color: colors.gold400, fontSize: 13, fontWeight: '600' },
});
