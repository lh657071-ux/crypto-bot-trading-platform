import React, { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Provider } from 'react-redux';
import { Slot, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { store } from '../src/store/store';
import { useAppDispatch, useAppSelector } from '../src/store/hooks';
import { bootstrap } from '../src/store/authSlice';
import { colors } from '../src/theme';

function AuthGate() {
  const dispatch = useAppDispatch();
  const { token, bootstrapped } = useAppSelector((s) => s.auth);
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    dispatch(bootstrap());
  }, [dispatch]);

  useEffect(() => {
    if (!bootstrapped) return;
    const inAuthGroup = segments[0] === '(tabs)';
    if (!token && inAuthGroup) {
      router.replace('/login');
    } else if (token && !inAuthGroup) {
      router.replace('/(tabs)');
    }
  }, [token, bootstrapped, segments]);

  if (!bootstrapped) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.ink950, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold500} />
      </View>
    );
  }

  return <Slot />;
}

export default function RootLayout() {
  return (
    <Provider store={store}>
      <StatusBar style="light" />
      <AuthGate />
    </Provider>
  );
}
