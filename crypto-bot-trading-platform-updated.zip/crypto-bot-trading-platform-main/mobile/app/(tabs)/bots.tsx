import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { botsApi, exchangeKeysApi } from '../../src/api/endpoints';
import type { ExchangeApiKey, TradingBot, TradingMode } from '../../src/types';
import { EmptyState, PrimaryButton, StatusPill } from '../../src/components/ui';
import { colors } from '../../src/theme';

const TRADING_MODES: TradingMode[] = [
  'AUTO_GRID',
  'AUTO_GRID_FUTURES',
  'FUTURES_GRID',
  'DCA_FUTURES',
  'MARTINGALE',
  'MARTINGALE_FUTURES',
  'SNOWBALL_GRID',
  'SNOWBALL_FUTURES',
];

export default function BotsScreen() {
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [keys, setKeys] = useState<ExchangeApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  async function refresh() {
    const [botsRes, keysRes] = await Promise.all([botsApi.list(), exchangeKeysApi.list()]);
    setBots(botsRes.data.data || []);
    setKeys(keysRes.data.data || []);
  }

  useFocusEffect(
    useCallback(() => {
      refresh().finally(() => setLoading(false));
    }, [])
  );

  async function handleStatus(bot: TradingBot, status: string) {
    setBusyId(bot.id);
    try {
      await botsApi.setStatus(bot.id, status);
      await refresh();
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.error || 'Failed to update bot');
    } finally {
      setBusyId(null);
    }
  }

  function handleDelete(bot: TradingBot) {
    Alert.alert('Delete bot', `Delete "${bot.name}"? This cannot be undone.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setBusyId(bot.id);
          try {
            await botsApi.remove(bot.id);
            await refresh();
          } catch (err: any) {
            Alert.alert('Error', err?.response?.data?.error || 'Failed to delete bot');
          } finally {
            setBusyId(null);
          }
        },
      },
    ]);
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.gold500} />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <View style={{ marginBottom: 12 }}>
          <PrimaryButton label="New bot" onPress={() => setModalOpen(true)} />
        </View>

        {bots.length === 0 ? (
          <EmptyState
            title="No bots yet"
            hint={keys.length === 0 ? 'Add an exchange API key in Settings first.' : 'Create your first bot above.'}
          />
        ) : (
          bots.map((bot) => (
            <View key={bot.id} style={styles.card}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardTitle}>{bot.name}</Text>
                <StatusPill status={bot.status} />
              </View>
              <Text style={styles.cardSub}>
                {bot.symbol} · {bot.trading_mode} · {bot.timeframe}
              </Text>
              <Text style={styles.cardSub}>
                {bot.win_rate}% win rate · {bot.total_trades} trades
              </Text>
              <View style={styles.actionsRow}>
                {bot.status !== 'active' && (
                  <ActionChip label="Start" onPress={() => handleStatus(bot, 'active')} busy={busyId === bot.id} />
                )}
                {bot.status === 'active' && (
                  <ActionChip label="Pause" onPress={() => handleStatus(bot, 'paused')} busy={busyId === bot.id} />
                )}
                {bot.status !== 'stopped' && (
                  <ActionChip label="Stop" onPress={() => handleStatus(bot, 'stopped')} busy={busyId === bot.id} />
                )}
                <ActionChip label="Delete" danger onPress={() => handleDelete(bot)} busy={busyId === bot.id} />
              </View>
            </View>
          ))
        )}
      </ScrollView>

      <Modal visible={modalOpen} animationType="slide" onRequestClose={() => setModalOpen(false)}>
        <CreateBotModal
          keys={keys}
          onClose={() => setModalOpen(false)}
          onCreated={() => {
            setModalOpen(false);
            refresh();
          }}
        />
      </Modal>
    </View>
  );
}

function ActionChip({
  label,
  onPress,
  danger,
  busy,
}: {
  label: string;
  onPress: () => void;
  danger?: boolean;
  busy?: boolean;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={busy}
      style={[styles.chip, danger && { borderColor: colors.fall + '66' }, busy && { opacity: 0.5 }]}
    >
      <Text style={[styles.chipText, danger && { color: colors.fall }]}>{label}</Text>
    </TouchableOpacity>
  );
}

function CreateBotModal({
  keys,
  onClose,
  onCreated,
}: {
  keys: ExchangeApiKey[];
  onClose: () => void;
  onCreated: () => void;
}) {
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('BTC/USDT');
  const [initialCapital, setInitialCapital] = useState('1000');
  const [modeIndex, setModeIndex] = useState(0);
  const [keyIndex, setKeyIndex] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    if (keys.length === 0) {
      Alert.alert('No exchange key', 'Add an exchange API key in Settings first.');
      return;
    }
    setSubmitting(true);
    try {
      await botsApi.create({
        name,
        symbol,
        exchangeApiKeyId: keys[keyIndex].id,
        tradingMode: TRADING_MODES[modeIndex],
        initialCapital: Number(initialCapital),
        timeframe: '1h',
        isPaperTrading: true,
      });
      onCreated();
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.error || 'Failed to create bot');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <View style={[styles.screen, { padding: 20, paddingTop: 60 }]}>
      <Text style={styles.modalTitle}>New bot</Text>

      <Text style={styles.label}>Name</Text>
      <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="BTC grid bot" placeholderTextColor={colors.mist400} />

      <Text style={styles.label}>Symbol</Text>
      <TextInput style={styles.input} value={symbol} onChangeText={setSymbol} placeholderTextColor={colors.mist400} />

      <Text style={styles.label}>Exchange key</Text>
      {keys.length === 0 ? (
        <Text style={styles.cardSub}>No keys connected — add one in Settings.</Text>
      ) : (
        <View style={styles.pickerRow}>
          {keys.map((k, i) => (
            <TouchableOpacity
              key={k.id}
              onPress={() => setKeyIndex(i)}
              style={[styles.pickerOption, i === keyIndex && styles.pickerOptionActive]}
            >
              <Text style={styles.chipText}>{k.exchange_name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <Text style={styles.label}>Trading mode</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }}>
        {TRADING_MODES.map((mode, i) => (
          <TouchableOpacity
            key={mode}
            onPress={() => setModeIndex(i)}
            style={[styles.pickerOption, i === modeIndex && styles.pickerOptionActive]}
          >
            <Text style={styles.chipText}>{mode}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Text style={styles.label}>Initial capital (USDT)</Text>
      <TextInput
        style={styles.input}
        value={initialCapital}
        onChangeText={setInitialCapital}
        keyboardType="numeric"
        placeholderTextColor={colors.mist400}
      />

      <View style={{ marginTop: 16, gap: 10 }}>
        <PrimaryButton label={submitting ? 'Creating…' : 'Create bot'} onPress={handleSubmit} loading={submitting} />
        <PrimaryButton label="Cancel" onPress={onClose} variant="ghost" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink950 },
  center: { flex: 1, backgroundColor: colors.ink950, alignItems: 'center', justifyContent: 'center' },
  card: { borderWidth: 1, borderColor: colors.ink700, borderRadius: 4, padding: 14, marginBottom: 10 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardTitle: { color: colors.mist50, fontSize: 15, fontWeight: '600' },
  cardSub: { color: colors.mist400, fontSize: 12, marginTop: 4 },
  actionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  chip: {
    borderWidth: 1,
    borderColor: colors.ink600,
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  chipText: { color: colors.mist100, fontSize: 12 },
  modalTitle: { color: colors.mist50, fontSize: 20, fontWeight: '700', marginBottom: 16 },
  label: { color: colors.mist300, fontSize: 12, marginBottom: 6, marginTop: 12 },
  input: {
    backgroundColor: colors.ink900,
    borderColor: colors.ink600,
    borderWidth: 1,
    borderRadius: 4,
    color: colors.mist50,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  pickerRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pickerOption: {
    borderWidth: 1,
    borderColor: colors.ink600,
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginRight: 8,
  },
  pickerOptionActive: { borderColor: colors.gold500, backgroundColor: colors.gold500 + '1A' },
});
