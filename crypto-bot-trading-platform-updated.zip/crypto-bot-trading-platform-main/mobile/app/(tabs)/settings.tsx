import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { exchangeKeysApi } from '../../src/api/endpoints';
import { useAppDispatch, useAppSelector } from '../../src/store/hooks';
import { logout } from '../../src/store/authSlice';
import type { ExchangeApiKey } from '../../src/types';
import { EmptyState, PrimaryButton } from '../../src/components/ui';
import { colors } from '../../src/theme';

const EXCHANGES = ['binance', 'bybit', 'okx', 'kucoin'];

export default function SettingsScreen() {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const user = useAppSelector((s) => s.auth.user);
  const [keys, setKeys] = useState<ExchangeApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);

  async function refresh() {
    const res = await exchangeKeysApi.list();
    setKeys(res.data.data || []);
  }

  useFocusEffect(
    useCallback(() => {
      refresh().finally(() => setLoading(false));
    }, [])
  );

  function handleRemove(key: ExchangeApiKey) {
    Alert.alert('Remove key', `Remove the ${key.exchange_name} API key?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          await exchangeKeysApi.remove(key.id);
          refresh();
        },
      },
    ]);
  }

  async function handleLogout() {
    await dispatch(logout());
    router.replace('/login');
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.gold500} />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <View style={styles.profileCard}>
          <Text style={styles.profileName}>{user?.username}</Text>
          <Text style={styles.profileEmail}>{user?.email}</Text>
        </View>

        <Text style={styles.sectionTitle}>Exchange keys</Text>
        <View style={{ marginBottom: 12 }}>
          <PrimaryButton label="Add key" onPress={() => setModalOpen(true)} />
        </View>

        {keys.length === 0 ? (
          <EmptyState title="No exchange keys connected" hint="Add one so your bots can trade." />
        ) : (
          keys.map((key) => (
            <View key={key.id} style={styles.row}>
              <View>
                <Text style={styles.rowTitle}>{key.exchange_name}</Text>
                <Text style={styles.rowSub}>
                  {key.api_key.slice(0, 4)}••••••••{key.api_key.slice(-4)}
                </Text>
              </View>
              <TouchableOpacity onPress={() => handleRemove(key)}>
                <Text style={{ color: colors.fall, fontSize: 13 }}>Remove</Text>
              </TouchableOpacity>
            </View>
          ))
        )}

        <View style={{ marginTop: 24 }}>
          <PrimaryButton label="Sign out" onPress={handleLogout} variant="danger" />
        </View>
      </ScrollView>

      <Modal visible={modalOpen} animationType="slide" onRequestClose={() => setModalOpen(false)}>
        <AddKeyModal
          onClose={() => setModalOpen(false)}
          onCreated={() => {
            setModalOpen(false);
            refresh();
          }}
        />
      </Modal>
    </View>
  );
}

function AddKeyModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [exchangeIndex, setExchangeIndex] = useState(0);
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    setSubmitting(true);
    try {
      await exchangeKeysApi.create({
        exchangeName: EXCHANGES[exchangeIndex],
        apiKey,
        apiSecret,
        passphrase: passphrase || undefined,
      });
      onCreated();
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.error || 'Failed to save key');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <View style={[styles.screen, { padding: 20, paddingTop: 60 }]}>
      <Text style={styles.modalTitle}>Add exchange key</Text>

      <Text style={styles.label}>Exchange</Text>
      <View style={styles.pickerRow}>
        {EXCHANGES.map((ex, i) => (
          <TouchableOpacity
            key={ex}
            onPress={() => setExchangeIndex(i)}
            style={[styles.pickerOption, i === exchangeIndex && styles.pickerOptionActive]}
          >
            <Text style={{ color: colors.mist100, fontSize: 12 }}>{ex}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>API key</Text>
      <TextInput style={styles.input} value={apiKey} onChangeText={setApiKey} autoCapitalize="none" placeholderTextColor={colors.mist400} />

      <Text style={styles.label}>API secret</Text>
      <TextInput
        style={styles.input}
        value={apiSecret}
        onChangeText={setApiSecret}
        secureTextEntry
        autoCapitalize="none"
        placeholderTextColor={colors.mist400}
      />

      <Text style={styles.label}>Passphrase (some exchanges only)</Text>
      <TextInput
        style={styles.input}
        value={passphrase}
        onChangeText={setPassphrase}
        autoCapitalize="none"
        placeholderTextColor={colors.mist400}
      />

      <View style={{ marginTop: 16, gap: 10 }}>
        <PrimaryButton label={submitting ? 'Saving…' : 'Save key'} onPress={handleSubmit} loading={submitting} />
        <PrimaryButton label="Cancel" onPress={onClose} variant="ghost" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink950 },
  center: { flex: 1, backgroundColor: colors.ink950, alignItems: 'center', justifyContent: 'center' },
  profileCard: { borderWidth: 1, borderColor: colors.ink700, borderRadius: 4, padding: 14, marginBottom: 20 },
  profileName: { color: colors.mist50, fontSize: 16, fontWeight: '600' },
  profileEmail: { color: colors.mist400, fontSize: 13, marginTop: 2 },
  sectionTitle: { color: colors.mist50, fontSize: 16, fontWeight: '600', marginBottom: 10 },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.ink700,
    borderRadius: 4,
    padding: 12,
    marginBottom: 8,
  },
  rowTitle: { color: colors.mist50, fontSize: 14, textTransform: 'capitalize' },
  rowSub: { color: colors.mist400, fontSize: 12, marginTop: 2 },
  modalTitle: { color: colors.mist50, fontSize: 20, fontWeight: '700', marginBottom: 16 },
  label: { color: colors.mist300, fontSize: 12, marginBottom: 6, marginTop: 12 },
  input: {
    backgroundColor: colors.ink900,
    borderColor: colors.ink600,
    borderWidth: 1,
    borderRadius: 4,
    color: colors.mist50,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  pickerRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pickerOption: {
    borderWidth: 1,
    borderColor: colors.ink600,
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginRight: 8,
  },
  pickerOptionActive: { borderColor: colors.gold500, backgroundColor: colors.gold500 + '1A' },
});
