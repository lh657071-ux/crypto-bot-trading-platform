import React, { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { ordersApi } from '../../src/api/endpoints';
import type { Order } from '../../src/types';
import { EmptyState, StatusPill } from '../../src/components/ui';
import { colors } from '../../src/theme';

export default function OrdersScreen() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useFocusEffect(
    useCallback(() => {
      ordersApi
        .list(100)
        .then((res) => setOrders(res.data.data || []))
        .finally(() => setLoading(false));
    }, [])
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.gold500} />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <FlatList
        contentContainerStyle={{ padding: 16 }}
        data={orders}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<EmptyState title="No orders yet" hint="Orders placed by your bots will appear here." />}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.symbol}>{item.symbol}</Text>
              <Text style={styles.meta}>
                <Text style={{ color: item.order_side === 'buy' ? colors.rise : colors.fall }}>
                  {item.order_side?.toUpperCase()}
                </Text>{' '}
                · {item.order_type} · {item.amount}
              </Text>
            </View>
            <StatusPill status={item.status} />
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink950 },
  center: { flex: 1, backgroundColor: colors.ink950, alignItems: 'center', justifyContent: 'center' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.ink700,
    borderRadius: 4,
    padding: 12,
    marginBottom: 8,
  },
  symbol: { color: colors.mist50, fontSize: 14, fontWeight: '500' },
  meta: { color: colors.mist400, fontSize: 12, marginTop: 2 },
});
