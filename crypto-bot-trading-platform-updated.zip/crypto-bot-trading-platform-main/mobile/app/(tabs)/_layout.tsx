import React from 'react';
import { Tabs } from 'expo-router';
import { Text } from 'react-native';
import { colors } from '../../src/theme';

function TabIcon({ symbol, focused }: { symbol: string; focused: boolean }) {
  return (
    <Text style={{ fontSize: 18, color: focused ? colors.gold500 : colors.mist400 }}>{symbol}</Text>
  );
}

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: colors.ink950 },
        headerTitleStyle: { color: colors.mist50 },
        headerShadowVisible: false,
        tabBarStyle: { backgroundColor: colors.ink900, borderTopColor: colors.ink700 },
        tabBarActiveTintColor: colors.gold500,
        tabBarInactiveTintColor: colors.mist400,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{ title: 'Overview', tabBarIcon: ({ focused }) => <TabIcon symbol="◧" focused={focused} /> }}
      />
      <Tabs.Screen
        name="bots"
        options={{ title: 'Bots', tabBarIcon: ({ focused }) => <TabIcon symbol="◔" focused={focused} /> }}
      />
      <Tabs.Screen
        name="orders"
        options={{ title: 'Orders', tabBarIcon: ({ focused }) => <TabIcon symbol="≡" focused={focused} /> }}
      />
      <Tabs.Screen
        name="settings"
        options={{ title: 'Settings', tabBarIcon: ({ focused }) => <TabIcon symbol="⚙" focused={focused} /> }}
      />
    </Tabs>
  );
}
