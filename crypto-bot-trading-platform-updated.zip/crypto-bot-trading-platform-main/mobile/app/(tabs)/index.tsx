import React, { useCallback, useState } from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { botsApi, ordersApi } from '../../src/api/endpoints';
import type { Order, TradingBot } from '../../src/types';
import { EmptyState, StatCard, StatusPill } from '../../src/components/ui';
import { colors } from '../../src/theme';

export default function DashboardScreen() {
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  async function load() {
    const [botsRes, ordersRes] = await Promise.all([botsApi.list(), ordersApi.list(8)]);
    setBots(botsRes.data.data || []);
    setOrders(ordersRes.data.data || []);
  }

  useFocusEffect(
    useCallback(() => {
      load().finally(() => setLoading(false));
    }, [])
  );

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.gold500} />
      </View>
    );
  }

  const activeBots = bots.filter((b) => b.status === 'active');
  const totalTrades = bots.reduce((sum, b) => sum + (b.total_trades || 0), 0);
  const avgWinRate =
    bots.length > 0
      ? (bots.reduce((sum, b) => sum + Number(b.win_rate || 0), 0) / bots.length).toFixed(1)
      : '0.0';

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={{ padding: 16 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.gold500} />}
    >
      <View style={styles.statsRow}>
        <StatCard label="Active bots" value={String(activeBots.length)} hint={`of ${bots.length} total`} />
        <StatCard label="Total trades" value={String(totalTrades)} />
        <StatCard label="Avg. win rate" value={`${avgWinRate}%`} />
        <StatCard label="Recent orders" value={String(orders.length)} />
      </View>

      <Text style={styles.sectionTitle}>Bots</Text>
      {bots.length === 0 ? (
        <EmptyState title="No bots yet" hint="Create one from the Bots tab to start trading." />
      ) : (
        bots.slice(0, 5).map((bot) => (
          <View key={bot.id} style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>{bot.name}</Text>
              <Text style={styles.rowSub}>
                {bot.symbol} · {bot.trading_mode}
              </Text>
            </View>
            <StatusPill status={bot.status} />
          </View>
        ))
      )}

      <Text style={styles.sectionTitle}>Recent orders</Text>
      {orders.length === 0 ? (
        <EmptyState title="No orders yet" hint="Orders placed by your bots will show up here." />
      ) : (
        orders.map((order) => (
          <View key={order.id} style={styles.row}>
            <Text style={[styles.rowTitle, { color: order.order_side === 'buy' ? colors.rise : colors.fall }]}>
              {order.order_side?.toUpperCase()}
            </Text>
            <Text style={[styles.rowSub, { flex: 1, marginLeft: 8 }]}>{order.symbol}</Text>
            <StatusPill status={order.status} />
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink950 },
  center: { flex: 1, backgroundColor: colors.ink950, alignItems: 'center', justifyContent: 'center' },
  statsRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  sectionTitle: { color: colors.mist50, fontSize: 16, fontWeight: '600', marginTop: 12, marginBottom: 8 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.ink700,
    borderRadius: 4,
    padding: 12,
    marginBottom: 8,
  },
  rowTitle: { color: colors.mist50, fontSize: 14, fontWeight: '500' },
  rowSub: { color: colors.mist400, fontSize: 12, marginTop: 2 },
});
