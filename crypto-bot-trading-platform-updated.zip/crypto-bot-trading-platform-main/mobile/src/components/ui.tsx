import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, statusColor } from '../theme';

export function StatusPill({ status }: { status: string }) {
  const c = statusColor(status);
  return (
    <View style={[styles.pill, { borderColor: c + '55', backgroundColor: c + '1A' }]}>
      <Text style={[styles.pillText, { color: c }]}>{status}</Text>
    </View>
  );
}

export function StatCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
      {hint ? <Text style={styles.statHint}>{hint}</Text> : null}
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  loading,
  disabled,
  variant = 'primary',
}: {
  label: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'ghost' | 'danger';
}) {
  const isPrimary = variant === 'primary';
  const isDanger = variant === 'danger';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.button,
        isPrimary && { backgroundColor: colors.gold500 },
        isDanger && { borderWidth: 1, borderColor: colors.fall + '66' },
        !isPrimary && !isDanger && { borderWidth: 1, borderColor: colors.ink600 },
        (disabled || loading) && { opacity: 0.5 },
        pressed && { opacity: 0.8 },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={isPrimary ? colors.ink950 : colors.mist100} />
      ) : (
        <Text
          style={[
            styles.buttonText,
            isPrimary && { color: colors.ink950 },
            isDanger && { color: colors.fall },
            !isPrimary && !isDanger && { color: colors.mist100 },
          ]}
        >
          {label}
        </Text>
      )}
    </Pressable>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyTitle}>{title}</Text>
      {hint ? <Text style={styles.emptyHint}>{hint}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  pill: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 4,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  pillText: { fontSize: 11, fontWeight: '500', textTransform: 'capitalize' },
  statCard: {
    flexBasis: '48%',
    backgroundColor: colors.ink900,
    borderColor: colors.ink700,
    borderWidth: 1,
    borderRadius: 4,
    padding: 14,
    marginBottom: 12,
  },
  statLabel: { color: colors.mist300, fontSize: 12 },
  statValue: { color: colors.mist50, fontSize: 22, marginTop: 4, fontWeight: '600' },
  statHint: { color: colors.mist400, fontSize: 11, marginTop: 2 },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: { fontSize: 14, fontWeight: '600' },
  empty: {
    borderWidth: 1,
    borderColor: colors.ink600,
    borderStyle: 'dashed',
    borderRadius: 4,
    paddingVertical: 40,
    alignItems: 'center',
  },
  emptyTitle: { color: colors.mist100, fontSize: 15 },
  emptyHint: { color: colors.mist400, fontSize: 13, marginTop: 4, textAlign: 'center', paddingHorizontal: 20 },
});
