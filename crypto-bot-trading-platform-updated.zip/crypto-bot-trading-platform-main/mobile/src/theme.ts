export const colors = {
  ink950: '#0A0E14',
  ink900: '#10161F',
  ink800: '#161D28',
  ink700: '#232B36',
  ink600: '#2E3844',
  mist400: '#5B6577',
  mist300: '#8A94A6',
  mist100: '#DCE1E8',
  mist50: '#E8ECEF',
  gold500: '#E8A33D',
  gold400: '#F0B968',
  rise: '#3DDC97',
  fall: '#E85D5D',
};

export function statusColor(status: string) {
  switch (status) {
    case 'active':
    case 'open':
    case 'filled':
      return colors.rise;
    case 'paused':
    case 'pending':
      return colors.gold500;
    case 'error':
    case 'rejected':
      return colors.fall;
    default:
      return colors.mist300;
  }
}
