import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authApi } from '../api/endpoints';
import type { User } from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  status: 'idle' | 'loading' | 'failed';
  bootstrapped: boolean;
  error: string | null;
}

const initialState: AuthState = {
  user: null,
  token: null,
  status: 'idle',
  bootstrapped: false,
  error: null,
};

function extractError(err: any): string {
  return err?.response?.data?.error || err?.message || 'Something went wrong';
}

export const bootstrap = createAsyncThunk('auth/bootstrap', async () => {
  const [token, userJson] = await Promise.all([
    AsyncStorage.getItem('token'),
    AsyncStorage.getItem('user'),
  ]);
  return {
    token,
    user: userJson ? (JSON.parse(userJson) as User) : null,
  };
});

export const login = createAsyncThunk(
  'auth/login',
  async (payload: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const res = await authApi.login(payload);
      if (!res.data.success || !res.data.data) throw new Error(res.data.error || 'Login failed');
      await AsyncStorage.setItem('token', res.data.data.token);
      await AsyncStorage.setItem('user', JSON.stringify(res.data.data.user));
      return res.data.data;
    } catch (err) {
      return rejectWithValue(extractError(err));
    }
  }
);

export const register = createAsyncThunk(
  'auth/register',
  async (
    payload: { email: string; username: string; password: string; fullName?: string },
    { rejectWithValue }
  ) => {
    try {
      const res = await authApi.register(payload);
      if (!res.data.success || !res.data.data) throw new Error(res.data.error || 'Registration failed');
      await AsyncStorage.setItem('token', res.data.data.token);
      await AsyncStorage.setItem('user', JSON.stringify(res.data.data.user));
      return res.data.data;
    } catch (err) {
      return rejectWithValue(extractError(err));
    }
  }
);

export const logout = createAsyncThunk('auth/logout', async () => {
  await AsyncStorage.multiRemove(['token', 'user']);
});

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearError(state) {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(bootstrap.fulfilled, (state, action) => {
        state.token = action.payload.token;
        state.user = action.payload.user;
        state.bootstrapped = true;
      })
      .addCase(bootstrap.rejected, (state) => {
        state.bootstrapped = true;
      })
      .addCase(login.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action: PayloadAction<{ user: User; token: string }>) => {
        state.status = 'idle';
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(login.rejected, (state, action) => {
        state.status = 'failed';
        state.error = (action.payload as string) || 'Login failed';
      })
      .addCase(register.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(register.fulfilled, (state, action: PayloadAction<{ user: User; token: string }>) => {
        state.status = 'idle';
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(register.rejected, (state, action) => {
        state.status = 'failed';
        state.error = (action.payload as string) || 'Registration failed';
      })
      .addCase(logout.fulfilled, (state) => {
        state.user = null;
        state.token = null;
      });
  },
});

export const { clearError } = authSlice.actions;
export default authSlice.reducer;
