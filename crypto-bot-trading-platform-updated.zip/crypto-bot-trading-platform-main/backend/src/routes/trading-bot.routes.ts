import express, { Router, Response } from 'express';
import TradingBotRepository from '../repositories/trading-bot.repository';
import ExchangeApiKeyRepository from '../repositories/exchange-api-key.repository';
import { requireAuth, AuthRequest } from '../middleware/auth.middleware';

const router: Router = express.Router();

const VALID_MODES = [
  'AUTO_GRID',
  'AUTO_GRID_FUTURES',
  'FUTURES_GRID',
  'DCA_FUTURES',
  'MARTINGALE',
  'MARTINGALE_FUTURES',
  'SNOWBALL_GRID',
  'SNOWBALL_FUTURES',
];

const VALID_STATUSES = ['active', 'paused', 'stopped', 'error'];

router.use(requireAuth);

/**
 * GET /api/bots
 * List all bots for the authenticated user
 */
router.get('/', async (req: AuthRequest, res: Response) => {
  try {
    const bots = await TradingBotRepository.findByUser(req.userId!);
    res.json({ success: true, data: bots });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Internal server error' });
  }
});

/**
 * GET /api/bots/:id
 */
router.get('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const bot = await TradingBotRepository.findById(req.params.id);
    if (!bot || bot.user_id !== req.userId) {
      return res.status(404).json({ success: false, error: 'Bot not found' });
    }
    res.json({ success: true, data: bot });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Internal server error' });
  }
});

/**
 * POST /api/bots
 * Create a new trading bot
 */
router.post('/', async (req: AuthRequest, res: Response) => {
  try {
    const {
      exchangeApiKeyId,
      name,
      description,
      symbol,
      tradingMode,
      isPaperTrading,
      initialCapital,
      timeframe,
      useIndicators,
      minSignalStrength,
      settings,
    } = req.body;

    if (!exchangeApiKeyId || !name || !symbol || !tradingMode || initialCapital === undefined) {
      return res.status(400).json({
        success: false,
        error: 'exchangeApiKeyId, name, symbol, tradingMode and initialCapital are required',
      });
    }

    if (!VALID_MODES.includes(tradingMode)) {
      return res.status(400).json({ success: false, error: `tradingMode must be one of: ${VALID_MODES.join(', ')}` });
    }

    // Confirm the API key belongs to this user
    const apiKey = await ExchangeApiKeyRepository.findById(exchangeApiKeyId);
    if (!apiKey || apiKey.user_id !== req.userId) {
      return res.status(404).json({ success: false, error: 'Exchange API key not found' });
    }

    const bot = await TradingBotRepository.create(req.userId!, exchangeApiKeyId, {
      name,
      description,
      symbol,
      trading_mode: tradingMode,
      is_paper_trading: isPaperTrading,
      initial_capital: initialCapital,
      timeframe,
      use_indicators: useIndicators,
      min_signal_strength: minSignalStrength,
      settings,
    });

    if (!bot) {
      return res.status(500).json({ success: false, error: 'Failed to create bot' });
    }

    res.status(201).json({ success: true, data: bot });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Internal server error' });
  }
});

/**
 * PUT /api/bots/:id
 * Update bot configuration
 */
router.put('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const existing = await TradingBotRepository.findById(req.params.id);
    if (!existing || existing.user_id !== req.userId) {
      return res.status(404).json({ success: false, error: 'Bot not found' });
    }

    const allowedFields = [
      'name',
      'description',
      'symbol',
      'trading_mode',
      'is_paper_trading',
      'initial_capital',
      'position_size',
      'leverage',
      'timeframe',
      'use_indicators',
      'min_signal_strength',
      'settings',
    ];

    const updates: Record<string, any> = {};
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates[field] = field === 'settings' ? JSON.stringify(req.body[field]) : req.body[field];
      }
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ success: false, error: 'No valid fields to update' });
    }

    const bot = await TradingBotRepository.update(req.params.id, updates);
    res.json({ success: true, data: bot });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Internal server error' });
  }
});

/**
 * PATCH /api/bots/:id/status
 * Start/pause/stop a bot
 */
router.patch('/:id/status', async (req: AuthRequest, res: Response) => {
  try {
    const { status } = req.body;

    if (!status || !VALID_STATUSES.includes(status)) {
      return res.status(400).json({ success: false, error: `status must be one of: ${VALID_STATUSES.join(', ')}` });
    }

    const existing = await TradingBotRepository.findById(req.params.id);
    if (!existing || existing.user_id !== req.userId) {
      return res.status(404).json({ success: false, error: 'Bot not found' });
    }

    const success = await TradingBotRepository.updateStatus(req.params.id, status);
    if (!success) {
      return res.status(500).json({ success: false, error: 'Failed to update bot status' });
    }

    res.json({ success: true, message: `Bot status updated to ${status}` });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Internal server error' });
  }
});

/**
 * DELETE /api/bots/:id
 */
router.delete('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const existing = await TradingBotRepository.findById(req.params.id);
    if (!existing || existing.user_id !== req.userId) {
      return res.status(404).json({ success: false, error: 'Bot not found' });
    }

    const success = await TradingBotRepository.delete(req.params.id);
    if (!success) {
      return res.status(500).json({ success: false, error: 'Failed to delete bot' });
    }

    res.json({ success: true, message: 'Bot deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Internal server error' });
  }
});

export default router;
